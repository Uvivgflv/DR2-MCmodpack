uniform sampler2D gcolor;

uniform float frameTimeCounter;
varying vec4 texcoord;
varying vec4 color;

void main()
{
  vec4 finalColor = texture2D(gcolor, (texcoord.st + (frameTimeCounter/300))*20);

  gl_FragData[0] = finalColor*color;
}
