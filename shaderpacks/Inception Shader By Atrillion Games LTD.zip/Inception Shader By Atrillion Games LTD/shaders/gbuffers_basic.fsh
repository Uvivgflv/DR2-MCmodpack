#version 120

varying vec4 color;
//#define USE_DOF
//#ifdef USE_DOF

void main() {

	gl_FragData[0] = color;
	gl_FragData[1] = vec4(vec3(gl_FragCoord.z), 1.0);
}
